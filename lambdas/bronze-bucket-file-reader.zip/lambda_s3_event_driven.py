import json
import os
import uuid
import time
import urllib.parse
from datetime import datetime

import boto3
from botocore.exceptions import ClientError

from openai import OpenAI

REGION = os.getenv("AWS_REGION", "ap-southeast-2")
S3 = boto3.client("s3", region_name=REGION)
TEXTRACT = boto3.client("textract", region_name=REGION)

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
openai_client = OpenAI(api_key="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")

BRONZE_BUCKET = os.getenv("BRONZE_BUCKET", "bronze-bucket-icvt")
SILVER_BUCKET = os.getenv("SILVER_BUCKET", "silver-bucket-icvt")

TEXTRACT_POLL_INITIAL_DELAY = float(os.getenv("TEXTRACT_POLL_INITIAL_DELAY", "1.0"))   
TEXTRACT_POLL_MAX_DELAY = float(os.getenv("TEXTRACT_POLL_MAX_DELAY", "6.0"))           
TEXTRACT_POLL_MAX_WAIT = float(os.getenv("TEXTRACT_POLL_MAX_WAIT", "240.0"))           


def lambda_handler(event, context):
    print(f"Lambda triggered with event: {json.dumps(event, default=str)}")

    if "Records" in event:
        results = []
        for record in event["Records"]:
            if "s3" in record:
                bucket_name = record["s3"]["bucket"]["name"]
                file_key = urllib.parse.unquote_plus(record["s3"]["object"]["key"])

                if file_key.lower().endswith((".pdf", ".tiff", ".tif", ".png", ".jpg", ".jpeg")):
                    result = process_document_to_silver(bucket_name, file_key, SILVER_BUCKET)
                    results.append(result)
                else:
                    results.append({
                        "file_key": file_key,
                        "status": "skipped",
                        "reason": "Unsupported extension"
                    })

        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": f"Processed {len(results)} files",
                "results": results
            }, ensure_ascii=False)
        }

    else:
        file_key = event.get("file_key")
        source_bucket = event.get("bucket", BRONZE_BUCKET)

        if not file_key:
            return {"statusCode": 400, "body": json.dumps({"error": "Provide file_key"}, ensure_ascii=False)}

        result = process_document_to_silver(source_bucket, file_key, SILVER_BUCKET)
        return {"statusCode": 200, "body": json.dumps(result, ensure_ascii=False, default=str)}



def deduplicate_by_confidence(items):
    unique = {}
    for item in items:
        k = (item.get("key") or "").strip().lower()
        if not k:
            k = f"__orig__:{item.get('original_key')}"
        if k not in unique or (item.get("confidence", 0) or 0) > (unique[k].get("confidence", 0) or 0):
            unique[k] = item
    return list(unique.values())


def is_pdf_or_tiff(key: str) -> bool:
    k = key.lower()
    return k.endswith(".pdf") or k.endswith(".tiff") or k.endswith(".tif")


def is_image(key: str) -> bool:
    k = key.lower()
    return k.endswith(".png") or k.endswith(".jpg") or k.endswith(".jpeg")


def head_object_or_error(bucket: str, key: str):
    try:
        S3.head_object(Bucket=bucket, Key=key)
    except ClientError as e:
        if e.response["Error"]["Code"] == "404":
            raise FileNotFoundError(f"File not found: s3://{bucket}/{key}")
        raise


def textract_analyze_sync(bucket: str, key: str) -> dict:
    return TEXTRACT.analyze_document(
        Document={"S3Object": {"Bucket": bucket, "Name": key}},
        FeatureTypes=["TABLES", "FORMS"]
    )


def textract_analyze_async(bucket: str, key: str) -> dict:
    start = TEXTRACT.start_document_analysis(
        DocumentLocation={"S3Object": {"Bucket": bucket, "Name": key}},
        FeatureTypes=["TABLES", "FORMS"]
    )
    job_id = start["JobId"]
    print(f"Textract async job started: {job_id}")

    delay = TEXTRACT_POLL_INITIAL_DELAY
    waited = 0.0

    pages = []
    next_token = None
    status_seen = None

    while True:
        if waited > TEXTRACT_POLL_MAX_WAIT:
            raise TimeoutError(f"Textract job {job_id} exceeded maximum wait of {TEXTRACT_POLL_MAX_WAIT}s")

        if next_token:
            resp = TEXTRACT.get_document_analysis(JobId=job_id, NextToken=next_token)
        else:
            resp = TEXTRACT.get_document_analysis(JobId=job_id)

        status = resp.get("JobStatus")
        status_seen = status
        print(f"Textract job {job_id} status: {status}")

        if status == "FAILED":
            raise RuntimeError(f"Textract job failed: {resp.get('StatusMessage')}")

        if "Blocks" in resp:
            pages.append(resp)

        next_token = resp.get("NextToken")

        if not next_token and status == "SUCCEEDED":
            break

        time.sleep(delay)
        waited += delay
        delay = min(delay * 1.5, TEXTRACT_POLL_MAX_DELAY)

    merged = {"Blocks": []}
    for p in pages:
        merged["Blocks"].extend(p.get("Blocks", []))
    return merged


def parse_kv_from_blocks(analyze_response: dict):
    key_map, value_map, block_map = {}, {}, {}
    for block in analyze_response.get("Blocks", []):
        block_map[block["Id"]] = block
        if block["BlockType"] == "KEY_VALUE_SET":
            if "KEY" in block.get("EntityTypes", []):
                key_map[block["Id"]] = block
            else:
                value_map[block["Id"]] = block

    forms_data = []
    for key_id in key_map:
        value_id, key_text, value_text = None, "", ""
        key_box, val_box = {}, {}
        conf = key_map[key_id].get("Confidence", 0)

        for rel in key_map[key_id].get("Relationships", []):
            if rel["Type"] == "CHILD":
                for child_id in rel["Ids"]:
                    if child_id in block_map and block_map[child_id]["BlockType"] == "WORD":
                        key_text += block_map[child_id].get("Text", "") + " "
            elif rel["Type"] == "VALUE":
                value_id = rel["Ids"][0] if rel["Ids"] else None

        if "Geometry" in key_map[key_id]:
            key_box = key_map[key_id]["Geometry"]["BoundingBox"]

        if value_id and value_id in value_map:
            for rel in value_map[value_id].get("Relationships", []):
                if rel["Type"] == "CHILD":
                    for child_id in rel["Ids"]:
                        if child_id in block_map and block_map[child_id]["BlockType"] == "WORD":
                            value_text += block_map[child_id].get("Text", "") + " "
            if "Geometry" in value_map[value_id]:
                val_box = value_map[value_id]["Geometry"]["BoundingBox"]

        if key_text.strip():
            forms_data.append({
                "original_key": str(uuid.uuid4()),
                "key": key_text.strip(),
                "value": value_text.strip(),
                "confidence": conf,
                "key_box": key_box,
                "value_box": val_box
            })
    return forms_data


def normalize_with_gpt(forms_data):
    gpt_input = [{"original_key": f["original_key"], "key": f["key"], "value": f["value"]} for f in forms_data]
    print("Sending forms data to GPT for normalization...")
    print("gpt_input", gpt_input)

    prompt = f"""
You are a data normalization model working with key-value pairs extracted from invoices via AWS Textract.

Your task:
Return a **JSON array** of objects, where each object represents a standardized field and contains:
- "original_key": the UUID from the input
- "field_name": one of the target standardized fields
- "value": the normalized textual value
- "gptConfidence": a numeric confidence score between 0.0 and 1.0 reflecting how confident you are in your mapping

Your output MUST strictly follow this JSON format:
[
{{
    "original_key": "...",
    "field_name": "Invoice Number",
    "value": "...",
    "gptConfidence": 0.95
}},
...
]

---

### Target standardized fields to detect:
1. **GST Number** — look for fields with "GST No", "GST Number".
2. **Invoice Date**
3. **Total Amount** — must correspond to the **total including GST**, not subtotal or other totals.
- Prefer fields containing "Total", "Incl", or "Total NZD Incl. GST".
4. **GST Amount** — tax value usually around 10–20% of total; 
- may appear near keys like "15%", "GST", or "Tax".
- if both a key with "%" and a numeric value exist, this is the GST Amount.
5. **Invoice Number** — look for fields with "Invoice No", "Invoice #", or "Invoice Number".
6. **Supplier/Vendor Name** — look for fields with "Account Name", "Beneficiary Name", "EFT Payments";
— detect the company name even if not explicitly labeled; 
- analyze the context of all text (e.g., addresses, contact info, phone numbers, email domains);
- choose the most probable supplier name (can be also Account Name)
7. **Account Number** — look for fields with "Acct", "Account Number", "Acc Number".
8. **ABN number** — look for fields with "ABN", "ABN Number".
9. **PO Number** — look for fields with "order No", "order Number".
10. **Creditor Name** — same as Supplier/Vendor Name.
11. **Creditor Code** — make Code from Creditor Name.
12. **Packing/Deliver/Con number** — look for fields with "Packing #", "Deliver #", "Con #", "Packing Number", "Packing No", "Deliver Number", "Deliver No", "Con Number", "Con No", "Co Number".
13. **Invoice Total** — same as Total Amount.

---

### Additional rules:
- If unsure about a field, output with "value": "" and "gptConfidence": 0.0, but always return JSON array.
- Include all fields listed.
- Do not include any fields beyond listed.
- Preserve the "original_key" from the input.

### Input data:
{json.dumps(gpt_input, ensure_ascii=False)}

Return only the final JSON array as valid JSON.
""".strip()

    gpt_response = openai_client.responses.create(
        model=OPENAI_MODEL,
        input=[{"role": "user", "content": prompt}],
        temperature=0
    )

    output_text = getattr(gpt_response, "output_text", "") or ""
    output_text = output_text.strip()
    if output_text.startswith("```"):
        output_text = output_text.split("```", 2)[-1]
    if output_text.endswith("```"):
        output_text = output_text.rsplit("```", 1)[0]

    print("=== GPT raw output ===")
    print(output_text)

    try:
        normalized_array = json.loads(output_text)
        if not isinstance(normalized_array, list):
            raise ValueError("GPT output is not a JSON array")
    except Exception as e:
        print("GPT output parse error:", str(e))
        normalized_array = []

    final_kv = []
    for item in normalized_array:
        orig_id = item.get("original_key")
        match = next((f for f in forms_data if f["original_key"] == orig_id), None)

        textract_confidence = (match["confidence"] / 100.0) if match and match.get("confidence") is not None else 0
        gpt_confidence = item.get("gptConfidence", 1.0)
        try:
            gpt_confidence = float(gpt_confidence)
        except Exception:
            gpt_confidence = 0.0

        combined_confidence = textract_confidence * gpt_confidence
        bbox = match.get("value_box") if match else {}

        if combined_confidence >= 0.9:
            color = "#2E7D32"  # green
        elif combined_confidence >= 0.7:
            color = "#F9A825"  # yellow
        else:
            color = "#C62828"  # red

        final_kv.append({
            "original_key": orig_id,
            "key": item.get("field_name"),
            "value": item.get("value", ""),
            "confidence": combined_confidence,
            "color": color,
            "BoundingBox": bbox
        })

    final_kv = deduplicate_by_confidence(final_kv)
    return final_kv


def process_document_to_silver(source_bucket: str, file_key: str, silver_bucket: str) -> dict:
    print(f"Processing document: s3://{source_bucket}/{file_key}")

    try:
        head_object_or_error(source_bucket, file_key)
        '''if is_pdf_or_tiff(file_key):
            analyze_response = textract_analyze_async(source_bucket, file_key)
        elif is_image(file_key):
            analyze_response = textract_analyze_sync(source_bucket, file_key)
        else:
            # Допустим, что PDF без расширения или иной формат – пробуем асинхронку,
            # а в случае ошибки вернём понятное сообщение
            analyze_response = textract_analyze_async(source_bucket, file_key)'''
        analyze_response = textract_analyze_async(source_bucket, file_key)
        forms_data = parse_kv_from_blocks(analyze_response)

        normalized_kv = normalize_with_gpt(forms_data)

        result = {
            "source_bucket": source_bucket,
            "source_file": file_key,
            "processed_at": datetime.utcnow().isoformat(),
            "processing_id": str(uuid.uuid4()),
            "normalized_data": normalized_kv,
            "status": "To Review"
        }

        clean_filename = os.path.splitext(os.path.basename(file_key))[0]
        folder_name = os.path.dirname(file_key)
        if folder_name:
            output_key = f"textract-results/{folder_name}/{clean_filename}.json"
        else:
            output_key = f"textract-results/{clean_filename}.json"

        S3.put_object(
            Bucket=silver_bucket,
            Key=output_key,
            Body=json.dumps(result, indent=2, ensure_ascii=False),
            ContentType="application/json"
        )

        return {
            "file_key": file_key,
            "status": "completed",
            "output_bucket": silver_bucket,
            "output_key": output_key,
            "processing_id": result["processing_id"]
        }

    except Exception as e:
        print(f"Error processing document: {str(e)}")
        return {
            "file_key": file_key,
            "status": "error",
            "error": str(e),
            "processing_id": str(uuid.uuid4())
        }