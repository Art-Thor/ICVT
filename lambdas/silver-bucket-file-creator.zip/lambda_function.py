import json
import boto3
import zipfile
import io
import csv
import os

s3 = boto3.client('s3')

def lambda_handler(event, context):
    try:
        print("Event received:", event)

        if isinstance(event, str):
            event = json.loads(event)

        body = event.get('body')
        if isinstance(body, str):
            body = json.loads(body)

        print("Parsed body:", body)

        filename = body.get('filename')
        json_data = body.get('json_data')
        folder = body.get('folder')

        if isinstance(json_data, str):
            try:
                json_data = json.loads(json_data)
            except Exception:
                pass  

        print("Filename:", filename)
        print("JSON data keys:", list(json_data.keys()) if isinstance(json_data, dict) else type(json_data))

        if not filename or not json_data:
            raise ValueError("Missing 'filename' or 'json_data' in request body")

        bronze_bucket = 'bronze-bucket-icvt'
        silver_bucket = 'silver-bucket-icvt'
        textract_prefix = 'textract-results'

        # ---------- 1. Загружаем исходный файл ----------
        key = f"{folder}/{filename}" if folder else filename
        print(f"Downloading from bronze: {bronze_bucket}/{key}")

        original_obj = s3.get_object(Bucket=bronze_bucket, Key=key)
        original_data = original_obj['Body'].read()

        # ---------- 2. Создаём CSV ----------
        csv_buffer = io.StringIO()
        csv_writer = csv.writer(csv_buffer)
        csv_writer.writerow(['key', 'value'])
        if isinstance(json_data, dict):
            for k, v in json_data.items():
                csv_writer.writerow([k, v])
        elif isinstance(json_data, list):
            for item in json_data:
                csv_writer.writerow([item.get('key'), item.get('value')])
        csv_data = csv_buffer.getvalue()

        # ---------- 3. Создаём ZIP ----------
        zip_buffer = io.BytesIO()
        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
            zip_file.writestr(filename, original_data)
            zip_file.writestr('data.csv', csv_data)

        zip_key = filename.rsplit('.', 1)[0] + '.zip'
        zip_buffer.seek(0)
        s3.put_object(Bucket=silver_bucket, Key=f"export/{folder}/{zip_key}", Body=zip_buffer.getvalue())
        print(f"ZIP uploaded: {silver_bucket}/export/{folder}/{zip_key}")

        # ---------- 4. Обновляем JSON в textract-results ----------
        base_name = os.path.splitext(filename)[0]
        textract_key = f"{textract_prefix}/{folder}/{base_name}.json"
        print(f"Looking for Textract JSON: {silver_bucket}/{textract_key}")

        try:
            textract_obj = s3.get_object(Bucket=silver_bucket, Key=textract_key)
            textract_data = json.loads(textract_obj['Body'].read().decode('utf-8'))
            print("Textract JSON keys:", list(textract_data.keys()))

            # обновляем статус
            #file_section = textract_data.get("normalized_data", {})
            if isinstance(textract_data, dict):
                textract_data["status"] = "Exported"
                print("Updated status to Exported")

                s3.put_object(
                    Bucket=silver_bucket,
                    Key=textract_key,
                    Body=json.dumps(textract_data, ensure_ascii=False, indent=2).encode('utf-8'),
                    ContentType='application/json'
                )
                print(f"Updated Textract JSON: {silver_bucket}/{textract_key}")
            else:
                print("⚠️ No file.normalized_data section found in JSON")
        except s3.exceptions.NoSuchKey:
            print(f"⚠️ Textract JSON not found: {textract_key}")
        except Exception as e:
            print(f"⚠️ Failed to update Textract JSON: {str(e)}")

        # ---------- 5. Возвращаем ответ ----------
        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({
                'message': f"ZIP created and uploaded to {silver_bucket}/{zip_key}",
                'updated_json': textract_key
            })
        }

    except Exception as e:
        print("Error occurred:", str(e))
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'error': str(e)})
        }